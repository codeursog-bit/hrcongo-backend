-- AlterEnum
-- This migration adds more than one value to an enum.
-- With PostgreSQL versions 11 and earlier, this is not possible
-- in a single migration. This can be worked around by creating
-- multiple migrations, each migration adding only one value to
-- the enum.


ALTER TYPE "AbsenceSubType" ADD VALUE 'RETRAIT_DEUIL';
ALTER TYPE "AbsenceSubType" ADD VALUE 'DEMENAGEMENT';

-- AlterTable
ALTER TABLE "loans" ADD COLUMN     "attachmentUrl" TEXT;
